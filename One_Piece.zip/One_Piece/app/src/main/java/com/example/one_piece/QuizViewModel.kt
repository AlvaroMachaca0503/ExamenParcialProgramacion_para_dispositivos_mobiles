package com.example.one_piece

class QuizViewModel : ViewModel() {

    private val _questions = MutableLiveData<List<Question>>()
    val questions: LiveData<List<Question>> get() = _questions

    private val _currentQuestionIndex = MutableLiveData(0)
    val currentQuestionIndex: LiveData<Int> get() = _currentQuestionIndex

    val currentQuestion: LiveData<Question> = Transformations.map(_currentQuestionIndex) {
        _questions.value?.get(it)
    }

    private val _score = MutableLiveData(0)
    val score: LiveData<Int> get() = _score

    val totalQuestions: Int
        get() = _questions.value?.size ?: 0

    init {
        loadQuestions()
    }

    private fun loadQuestions() {
        _questions.value = listOf(
            Question(
                text = "¿Cuál es el sueño de Monkey D. Luffy?",
                options = listOf(
                    "Ser el Rey de los Piratas",
                    "Encontrar el All Blue",
                    "Ser el mejor espadachín",
                    "Convertirse en Yonko"
                ),
                correctAnswerIndex = 0,
                explanation = "Luffy desea convertirse en el Rey de los Piratas."
            ),
            Question(
                text = "¿Quién es el médico de la tripulación de los Sombrero de Paja?",
                options = listOf("Chopper", "Brook", "Nami", "Usopp"),
                correctAnswerIndex = 0,
                explanation = "Tony Tony Chopper es el médico de la tripulación."
            ),
            Question(
                text = "¿Cuál es la recompensa actual de Monkey D. Luffy después de los eventos de Whole Cake Island?",
                options = listOf("1,500,000,000 Berries", "500,000,000 Berries", "1,000,000,000 Berries", "2,000,000,000 Berries"),
                correctAnswerIndex = 0,
                explanation = "La recompensa de Luffy aumentó a 1,500,000,000 Berries."
            ),
            Question(
                text = "¿Qué miembro de la tripulación es conocido como 'El Rey del Francotirador'?",
                options = listOf("Usopp", "Sanji", "Franky", "Zoro"),
                correctAnswerIndex = 0,
                explanation = "Usopp es conocido como 'Sogeking', el Rey del Francotirador."
            ),
            Question(
                text = "¿Cómo se llama la espada maldita que posee Roronoa Zoro?",
                options = listOf("Sandai Kitetsu", "Wado Ichimonji", "Shusui", "Yubashiri"),
                correctAnswerIndex = 0,
                explanation = "Sandai Kitetsu es la espada maldita que Zoro adquiere en Loguetown."
            ),
            Question(
                text = "¿Cuál es el nombre del barco actual de los Sombrero de Paja?",
                options = listOf("Thousand Sunny", "Going Merry", "Red Force", "Moby Dick"),
                correctAnswerIndex = 0,
                explanation = "El Thousand Sunny es el barco construido por Franky para reemplazar al Going Merry."
            ),
            Question(
                text = "¿Quién es el fundador y capitán de los Piratas de Barbanegra?",
                options = listOf("Marshall D. Teach", "Edward Newgate", "Kaido", "Shanks"),
                correctAnswerIndex = 0,
                explanation = "Marshall D. Teach, también conocido como Barbanegra, es el capitán de su propia tripulación."
            ),
            Question(
                text = "¿Qué fruta del diablo consumió Nico Robin?",
                options = listOf("Hana Hana no Mi", "Suna Suna no Mi", "Mero Mero no Mi", "Bara Bara no Mi"),
                correctAnswerIndex = 0,
                explanation = "La Hana Hana no Mi permite a Robin hacer florecer partes de su cuerpo en cualquier superficie."
            ),
            Question(
                text = "¿Cuál es el título que ostenta Silvers Rayleigh?",
                options = listOf("El Rey Oscuro", "El Héroe Marino", "El Fénix", "El Dragón Celestial"),
                correctAnswerIndex = 0,
                explanation = "Silvers Rayleigh es conocido como 'El Rey Oscuro', antiguo primer oficial de Roger."
            ),
            Question(
                text = "¿Quién es el padre biológico de Portgas D. Ace?",
                options = listOf("Gol D. Roger", "Monkey D. Dragon", "Edward Newgate", "Monkey D. Garp"),
                correctAnswerIndex = 0,
                explanation = "Gol D. Roger es el padre biológico de Ace."
            ),
            Question(
                text = "¿Cuál es el objetivo principal de la organización revolucionaria liderada por Monkey D. Dragon?",
                options = listOf(
                    "Derrocar al Gobierno Mundial",
                    "Encontrar el One Piece",
                    "Dominar el Nuevo Mundo",
                    "Convertirse en Yonko"
                ),
                correctAnswerIndex = 0,
                explanation = "La organización revolucionaria busca derrocar al Gobierno Mundial."
            ),
            Question(
                text = "¿Qué habilidad otorga la fruta Gomu Gomu no Mi a Luffy?",
                options = listOf(
                    "Convertir su cuerpo en goma",
                    "Manipular el fuego",
                    "Transformarse en luz",
                    "Controlar la gravedad"
                ),
                correctAnswerIndex = 0,
                explanation = "La Gomu Gomu no Mi convierte el cuerpo de Luffy en goma."
            ),
            Question(
                text = "¿Cuál es el mar de origen de la mayoría de los miembros de los Sombrero de Paja?",
                options = listOf("East Blue", "West Blue", "North Blue", "South Blue"),
                correctAnswerIndex = 0,
                explanation = "La mayoría de los miembros provienen del East Blue."
            ),
            Question(
                text = "¿Quién es el primer miembro en unirse a la tripulación de Luffy?",
                options = listOf("Roronoa Zoro", "Nami", "Sanji", "Usopp"),
                correctAnswerIndex = 0,
                explanation = "Roronoa Zoro es el primer miembro en unirse a Luffy."
            ),
            Question(
                text = "¿Qué arma utiliza Nami en combate?",
                options = listOf("Clima-Tact", "Espadas", "Pistolas", "Puños"),
                correctAnswerIndex = 0,
                explanation = "Nami utiliza el Clima-Tact para manipular el clima."
            ),
            Question(
                text = "¿Cuál es la profesión de Sanji en la tripulación?",
                options = listOf("Cocinero", "Navegante", "Arqueólogo", "Músico"),
                correctAnswerIndex = 0,
                explanation = "Sanji es el cocinero de los Sombrero de Paja."
            ),
            Question(
                text = "¿Quién es conocido como 'El Rey del Mar' en el universo de One Piece?",
                options = listOf("Neptuno", "Kaido", "Big Mom", "Barbanegra"),
                correctAnswerIndex = 0,
                explanation = "El Rey Neptuno es conocido como el gobernante del mar."
            ),
            Question(
                text = "¿Qué miembro de la tripulación puede transformarse en diferentes formas gracias a su fruta del diablo?",
                options = listOf("Chopper", "Brook", "Robin", "Franky"),
                correctAnswerIndex = 0,
                explanation = "Chopper comió la Hito Hito no Mi y puede transformarse."
            ),
            Question(
                text = "¿Cuál es el nombre del mineral que anula los poderes de las frutas del diablo?",
                options = listOf("Kairoseki", "Granito Marino", "Adam Wood", "Vivre Card"),
                correctAnswerIndex = 0,
                explanation = "El Kairoseki es un mineral que debilita a los usuarios de frutas del diablo."
            ),
            Question(
                text = "¿Qué personaje es el actual Almirante de Flota de la Marina?",
                options = listOf("Sakazuki (Akainu)", "Aokiji", "Kizaru", "Sengoku"),
                correctAnswerIndex = 0,
                explanation = "Sakazuki, también conocido como Akainu, es el Almirante de Flota."
            ),
            Question(
                text = "¿Cuál es la prisión más temida controlada por el Gobierno Mundial?",
                options = listOf("Impel Down", "Enies Lobby", "Marineford", "Dressrosa"),
                correctAnswerIndex = 0,
                explanation = "Impel Down es la prisión de máxima seguridad del Gobierno Mundial."
            )
        )
    }


    fun checkAnswer(selectedIndex: Int): Boolean {
        val correct = selectedIndex == currentQuestion.value?.correctAnswerIndex
        if (correct) {
            _score.value = _score.value?.plus(1)
        }
        return correct
    }

    fun moveToNextQuestion(): Boolean {
        return if ((_currentQuestionIndex.value ?: 0) < totalQuestions - 1) {
            _currentQuestionIndex.value = _currentQuestionIndex.value?.plus(1)
            true
        } else {
            false
        }
    }

    fun resetQuiz() {
        _currentQuestionIndex.value = 0
        _score.value = 0
    }
}
