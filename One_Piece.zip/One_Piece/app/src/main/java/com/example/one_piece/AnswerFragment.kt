package com.example.one_piece

class AnswerFragment : Fragment() {

    private var _binding: FragmentAnswerBinding? = null
    private val binding get() = _binding!!

    private val args: AnswerFragmentArgs by navArgs()
    private val quizViewModel: QuizViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentAnswerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val isCorrect = args.isCorrect
        val currentQuestion = quizViewModel.currentQuestion.value!!

        binding.resultTextView.text = if (isCorrect) "¡Correcto!" else "Incorrecto"
        binding.explanationTextView.text = currentQuestion.explanation

        binding.nextButton.setOnClickListener {
            if (quizViewModel.moveToNextQuestion()) {
                findNavController().navigate(R.id.action_answerFragment_to_questionFragment)
            } else {
                findNavController().navigate(R.id.action_answerFragment_to_resultFragment)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

