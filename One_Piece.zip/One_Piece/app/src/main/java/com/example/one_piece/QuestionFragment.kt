package com.example.one_piece

class QuestionFragment : Fragment() {

    private var _binding: FragmentQuestionBinding? = null
    private val binding get() = _binding!!

    private val quizViewModel: QuizViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentQuestionBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Observa cambios en la pregunta actual
        quizViewModel.currentQuestion.observe(viewLifecycleOwner) { question ->
            updateQuestion(question)
        }

        // Configura el botón de enviar
        binding.submitButton.setOnClickListener {
            val selectedOptionIndex = binding.optionsRadioGroup.indexOfChild(
                binding.optionsRadioGroup.findViewById(binding.optionsRadioGroup.checkedRadioButtonId)
            )
            val isCorrect = quizViewModel.checkAnswer(selectedOptionIndex)

            val action = QuestionFragmentDirections.actionQuestionFragmentToAnswerFragment(isCorrect)
            findNavController().navigate(action)
        }

        // Habilita el botón cuando se selecciona una opción
        binding.optionsRadioGroup.setOnCheckedChangeListener { _, _ ->
            binding.submitButton.isEnabled = true
        }
    }

    private fun updateQuestion(question: Question) {
        binding.questionTextView.text = question.text
        binding.optionsRadioGroup.removeAllViews()

        question.options.forEachIndexed { index, option ->
            val radioButton = RadioButton(requireContext())
            radioButton.id = View.generateViewId()
            radioButton.text = option
            binding.optionsRadioGroup.addView(radioButton)
        }

        // Actualiza la barra de progreso
        val progress = ((quizViewModel.currentQuestionIndex.value!! + 1) * 100) / quizViewModel.totalQuestions
        binding.progressBar.progress = progress
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
