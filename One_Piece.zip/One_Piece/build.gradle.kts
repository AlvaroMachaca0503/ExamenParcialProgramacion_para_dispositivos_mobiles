// Top-level build file where you can add configuration options common to all sub-projects/modules.

// build.gradle.kts (a nivel de proyecto)

plugins {
    alias(libs.plugins.androidApplication) apply false
    alias(libs.plugins.kotlinAndroid) apply false
}

tasks.register("clean", Delete::class) {
    delete(rootProject.buildDir)
}
